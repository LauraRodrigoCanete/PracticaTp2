ejemplo llamada:
-i resources/examples/ex1.json -t 100 -m gui