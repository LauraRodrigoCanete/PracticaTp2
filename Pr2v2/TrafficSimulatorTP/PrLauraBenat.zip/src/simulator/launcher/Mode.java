package simulator.launcher;

public enum Mode {
	GUI, CONSOLE;
}
